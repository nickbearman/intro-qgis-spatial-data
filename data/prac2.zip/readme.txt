Data for use in Practical 2 in Introduction to QGIS: Understanding and Presenting Spatial Data (https://github.com/nickbearman/intro-qgis-spatial-data)

prac2-imd-d-style.qml
=====================

IMD Style from the 2018 IMD data. Created by Alasdair Rae (see https://www.sheffield.ac.uk/usp/research/projects/english-indices-deprivation-2019 for more details). 

Downloaded and extracted from the QGIS project (https://sheffield.ac.uk/geography-planning/research/usp/projects/qgis-map-project).

prac2-data.gpkg
===============

southern_england-lsoa2021_imd2025
---------------------------------

IoD 2025 data for England. 

Information at https://www.gov.uk/government/statistics/english-indices-of-deprivation-2025/english-indices-of-deprivation-2025-statistical-release

Data downloaded from https://communitiesopendata-communities.hub.arcgis.com/datasets/4da63019f25546aa92a922a5ea682950_0/explore?location=52.614323%2C-2.489482%2C7.17 on 2026-02-11

Download as a GeoPackage
LSOA_IMD2025_OSGB1936_-8580071282870403721.gpkg

This has been cut down (to cover Ordnance Survey grids SU and TU), Simplified (10 meters) and had Population data from the 2021 Census added to it. See below for detailed overview. 


southern_england-counties_unitary_authorities_dec_2024
------------------------------------------------------

Counties and Unitary Authorities (December 2024) Boundaries UK BFC
Downloaded from https://geoportal.statistics.gov.uk/datasets/e0e00383f27d4437ae87d26e673c2d54_0/explore?location=50.712024%2C-0.548385%2C8 on 2026-02-11

Cut down to match the coverage of southern_england-lsoa2021_imd2025. Also Simplified to a Tolerance of 10 meters. 


regions_december_2024_boundaries
--------------------------------

Regions (December 2024) Boundaries EN BFC 
(used to be called Government Office Regions)
Used to show London in the Layout practical. 

Downloaded from https://geoportal.statistics.gov.uk/datasets/f181d27b5bac477388ce81ad935a1227_0/explore?location=52.741211%2C-1.412822%2C7 on 2026-02-11


Processing Information
======================

southern_england-lsoa2021_imd2025
---------------------------------

IoD 2025 data for England. 

Information at https://www.gov.uk/government/statistics/english-indices-of-deprivation-2025/english-indices-of-deprivation-2025-statistical-release

Data downloaded from https://communitiesopendata-communities.hub.arcgis.com/datasets/4da63019f25546aa92a922a5ea682950_0/explore?location=52.614323%2C-2.489482%2C7.17 on 2026-02-11

Download as a GeoPackage
LSOA_IMD2025_OSGB1936_-8580071282870403721.gpkg

This has been cut down (to cover Ordnance Survey grids SU and TU) for use with OS Greenspace Data in Practical 3 and 4 (Advanced QGIS course). 

From https://github.com/OrdnanceSurvey/osbng-grids/tree/main you can download Ordnance Survey locator grids, which show you where SU and TQ grids are. I am calling this 'Southern England'. 

I used Select by Location to select out the areas from the Counties and Unitary Authorities (December 2024) Boundaries UK BFC layer, using Intersect. 

Also add in Isle of Wight, as the map looks weird without it (even though it is not in SU and TQ grids). 

I used Select by Location to cut down the IMD data to the same area, and also added Isle of Wight in. 

The IMD data is at LSOA level. I added population from the 2021 Census data. 

From https://www.nomisweb.co.uk/sources/census_2021_bulk I downloaded TS007A 	Age by five-year age bands, census2021-ts007a.zip. 

I changed grouped 5 year age bands to 0 to 19, 20 to 64 and 65 and over. 

Then I joined using the LSOA Code. 

These two layers make the geopackage quite big (199 MB) so I have simplified them. 

Using Vector Geometry > Simplify and a Tolerance of 10 meters. 

Now there is a file size of 25mb. 

I also Renamed the fields so they don't have massively long file names, and use Refactor to convert strings to numbers where needed. 
